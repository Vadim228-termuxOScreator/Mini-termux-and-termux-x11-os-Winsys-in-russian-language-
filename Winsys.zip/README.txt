ГРАФИЧЕСКАЯ ОС ДЛЯ TERMUX
==========================

1. Установите Termux из F-Droid.
2. Скопируйте файл `Winsys.zip` и `install.sh` в Termux (в папку ~/storage/downloads или напрямую).
3. Запустите Termux и выполните:

   cd ~/storage/downloads
   bash install.sh

ИЛИ (для графической установки):
   bash setup_gui.sh

4. После установки запускайте ОС через:
   bash ~/Winsys/desktop.sh
