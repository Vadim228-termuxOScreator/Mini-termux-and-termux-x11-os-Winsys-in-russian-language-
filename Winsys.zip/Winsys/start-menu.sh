#!/data/data/com.termux/files/usr/bin/bash
app=$(zenity --list --title="Пуск" --column="Программы" "Firefox" "NetSurf" "Проводник" "Музыка" "YouTube" "Выход")
case "$app" in
    "Firefox") firefox & ;;
    "NetSurf") netsurf & ;;
    "Проводник") pcmanfm & ;;
    "Музыка") mpv ~/music & ;;
    "YouTube") am start -a android.intent.action.VIEW -d https://youtube.com ;;
    "Выход") pkill Xvnc ;;
esac
