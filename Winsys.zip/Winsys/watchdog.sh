#!/bin/bash
while true; do
    if ! pgrep -f "desktop.sh" >/dev/null; then
        DISPLAY=:1 feh -F "$HOME/Winsys/error/BSOD.png" &
        break
    fi
    sleep 2
done
