#!/data/data/com.termux/files/usr/bin/bash

CATEGORY=$(zenity --list --title="WinStore – Категории" --column="Категория" \
  "Браузеры" "Медиа" "Офис" "Игры" "Утилиты" "Графика" "Терминал" "Назад")

case $CATEGORY in
  "Браузеры")
    APP=$(zenity --list --title="Браузеры" --column="Приложение" \
      "Firefox" "NetSurf" "w3m" "lynx" "elinks")
    ;;
  "Медиа")
    APP=$(zenity --list --title="Медиа-плееры" --column="Приложение" \
      "MPV" "MOC (консольный плеер)" "cmus")
    ;;
  "Офис")
    APP=$(zenity --list --title="Офисные программы" --column="Приложение" \
      "Abiword (текстовый редактор)" "Gnumeric (таблицы)" "Ghostwriter (markdown)" "xpdf")
    ;;
  "Игры")
    APP=$(zenity --list --title="Игры" --column="Приложение" \
      "Nethack (приключение)" "Moon-Buggy (гонки)" "2048" "Nsnake (змейка)" "Doom (prboom)")
    ;;
  "Утилиты")
    APP=$(zenity --list --title="Системные утилиты" --column="Приложение" \
      "htop (монитор процессов)" "neofetch" "ranger (файловый менеджер)" "nano" "mc (Midnight Commander)")
    ;;
  "Графика")
    APP=$(zenity --list --title="Графика" --column="Приложение" \
      "mtpaint" "ImageMagick" "feh" "ristretto")
    ;;
  "Терминал")
    APP=$(zenity --list --title="Терминальные приложения" --column="Приложение" \
      "bash" "zsh" "fish" "tmux" "screen")
    ;;
  *)
    exit
    ;;
esac

# Установка выбранного приложения
case $APP in
  "Firefox") pkg install firefox -y ;;
  "NetSurf") pkg install netsurf -y ;;
  "w3m") pkg install w3m -y ;;
  "lynx") pkg install lynx -y ;;
  "elinks") pkg install elinks -y ;;

  "MPV") pkg install mpv -y ;;
  "MOC (консольный плеер)") pkg install moc -y ;;
  "cmus") pkg install cmus -y ;;

  "Abiword (текстовый редактор)") pkg install abiword -y ;;
  "Gnumeric (таблицы)") pkg install gnumeric -y ;;
  "Ghostwriter (markdown)") pkg install ghostwriter -y ;;
  "xpdf") pkg install xpdf -y ;;

  "Nethack (приключение)") pkg install nethack -y ;;
  "Moon-Buggy (гонки)") pkg install moon-buggy -y ;;
  "2048") pkg install 2048 -y ;;
  "Nsnake (змейка)") pkg install nsnake -y ;;
  "Doom (prboom)") pkg install prboom -y ;;

  "htop (монитор процессов)") pkg install htop -y ;;
  "neofetch") pkg install neofetch -y ;;
  "ranger (файловый менеджер)") pkg install ranger -y ;;
  "nano") pkg install nano -y ;;
  "mc (Midnight Commander)") pkg install mc -y ;;

  "mtpaint") pkg install mtpaint -y ;;
  "ImageMagick") pkg install imagemagick -y ;;
  "feh") pkg install feh -y ;;
  "ristretto") pkg install ristretto -y ;;

  "bash") pkg install bash -y ;;
  "zsh") pkg install zsh -y ;;
  "fish") pkg install fish -y ;;
  "tmux") pkg install tmux -y ;;
  "screen") pkg install screen -y ;;
esac
